<?php

// Composer'ın autoloader'ını dahil et
require_once __DIR__ . '/../vendor/autoload.php';

use Jose\Component\Core\AlgorithmManager;
use Jose\Component\KeyManagement\JWKFactory;
use Jose\Component\Signature\Algorithm\ES256;

// VAPID anahtarlarını oluştur
$algorithmManager = new AlgorithmManager([new ES256()]);
$jwk = JWKFactory::createECKey('P-256', ['alg' => 'ES256', 'use' => 'sig']);

$publicKey = base64_encode(json_encode($jwk->toPublic()->all()));
$privateKey = base64_encode(json_encode($jwk->all()));

echo "VAPID anahtarlarınız başarıyla oluşturuldu!<br><br>";
echo "Aşağıdaki satırları .env dosyanıza ekleyin:<br><br>";
echo "<pre>";
echo "vapid.publicKey = \"{$publicKey}\"\n";
echo "vapid.privateKey = \"{$privateKey}\"";
echo "</pre>";