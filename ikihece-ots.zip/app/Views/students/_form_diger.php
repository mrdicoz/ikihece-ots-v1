<h5 class="mb-3">Muhasebe Bilgileri</h5>
<div class="row">
    <div class="col-md-6 mb-3"><label class="form-label">Sözleşme No</label><input type="text" name="sozlesme_no" class="form-control" value="<?= old('sozlesme_no', $student['sozlesme_no'] ?? '') ?>"></div>
    <div class="col-md-6 mb-3"><label class="form-label">Sözleşme Tutarı</label><input type="text" name="sozlesme_tutari" class="form-control" value="<?= old('sozlesme_tutari', $student['sozlesme_tutari'] ?? '') ?>"></div>
</div>
<hr>

