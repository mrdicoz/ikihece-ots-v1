<!DOCTYPE html>
<html lang="tr" data-bs-theme="auto">
<head>
    <?= $this->include('layouts/partials/_head') ?>
</head>
<body>

    <?= $this->renderSection('main') ?>

    <?= $this->include('layouts/partials/_scripts') ?>
    
</body>
</html>