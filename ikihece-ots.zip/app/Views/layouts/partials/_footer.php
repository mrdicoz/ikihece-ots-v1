<footer class="text-center py-2 border-top">
    <small>&copy; <?= date('Y') ?> İkihece OTS. Tüm hakları saklıdır.</small>
</footer>